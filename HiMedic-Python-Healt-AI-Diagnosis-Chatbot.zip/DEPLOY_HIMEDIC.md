# 🚀 Panduan Deploy HiMedic ke Railway (Gratis & Step-by-Step)

> **Platform yang dipakai:** [Railway.app](https://railway.app) — gratis $5 credit/bulan, cukup untuk project kecil-menengah. Tidak perlu kartu kredit untuk mulai.

---

## 📋 Ringkasan Stack Aplikasi

| Komponen | Detail |
|---|---|
| Framework | Flask 2.0.3 |
| ML | TensorFlow-CPU 2.9.1, Keras, scikit-learn |
| Python | 3.10.13 |
| Server | Gunicorn (sudah ada di `Procfile`) |
| Dataset | CSV lokal + model `.h5` |

---

## ⚠️ Persiapan Sebelum Deploy

### 1. Install Git (jika belum ada)
Download di [git-scm.com](https://git-scm.com/downloads), lalu verifikasi:
```bash
git --version
```

### 2. Buat Akun GitHub (jika belum punya)
Daftar di [github.com](https://github.com) — gratis.

### 3. Buat Akun Railway
Daftar di [railway.app](https://railway.app) menggunakan akun GitHub kamu.

---

## 🔧 STEP 1 — Siapkan File Konfigurasi

Sebelum upload ke GitHub, pastikan beberapa file berikut sudah benar di folder projekmu.

### ✅ Cek `Procfile` (sudah ada, pastikan isinya benar)
```
web: gunicorn app:app --workers 1 --timeout 120
```
> Jangan ubah apapun, sudah benar.

### ✅ Cek `runtime.txt` (sudah ada)
```
python-3.10.13
```
> Sudah benar.

### ✅ Update `requirements.txt`

Buka file `requirements.txt`, **ganti seluruh isinya** dengan versi berikut (lebih stabil untuk deploy):

```
Flask==2.0.3
Werkzeug==2.0.3
keras==2.9.0
nltk==3.7
numpy==1.23.1
scikit-learn==1.1.3
tensorflow-cpu==2.9.1
pandas==1.5.2
gunicorn==20.1.0
h5py==3.7.0
```

> Ditambahkan `h5py` yang dibutuhkan untuk load model `.h5`.

### ✅ Buat file `nltk_setup.py` di root folder

TensorFlow dan NLTK butuh data yang didownload saat pertama jalan. Buat file baru bernama `nltk_setup.py`:

```python
import nltk
nltk.download('punkt')
nltk.download('wordnet')
nltk.download('omw-1.4')
```

### ✅ Modifikasi `app.py` — Jalankan NLTK Download Otomatis

Tambahkan baris berikut tepat **setelah baris `from flask import ...`** di `app.py`:

```python
import nltk
import os

# Download NLTK data jika belum ada (untuk environment production)
nltk_data_dir = os.path.join(os.path.expanduser("~"), "nltk_data")
if not os.path.exists(nltk_data_dir):
    nltk.download('punkt')
    nltk.download('wordnet')
    nltk.download('omw-1.4')
```

### ✅ Buat file `.gitignore` di root folder

```
__pycache__/
*.pyc
*.pyo
.env
.DS_Store
*.pkl.bak
venv/
env/
```

---

## 📁 STEP 2 — Upload ke GitHub

### 2.1 Buka Terminal / Command Prompt
Arahkan ke folder project HiMedic kamu:
```bash
cd path/ke/folder/HiMedic
```
Contoh Windows:
```bash
cd C:\Users\NamaKamu\Documents\HiMedic
```
Contoh Mac/Linux:
```bash
cd ~/Documents/HiMedic
```

### 2.2 Inisialisasi Git Repository
```bash
git init
git add .
git commit -m "Initial commit - HiMedic app"
```

### 2.3 Buat Repository Baru di GitHub
1. Buka [github.com](https://github.com) → Login
2. Klik tombol **"New"** (atau tombol **"+"** di kanan atas → New repository)
3. Isi nama repository: `himedic-app`
4. Pilih **Public** atau **Private** (keduanya bisa)
5. **Jangan centang** "Add README", "Add .gitignore", atau "License"
6. Klik **"Create repository"**

### 2.4 Hubungkan ke GitHub dan Push
GitHub akan menampilkan instruksi. Gunakan perintah berikut (ganti `USERNAME` dengan username GitHub kamu):

```bash
git remote add origin https://github.com/USERNAME/himedic-app.git
git branch -M main
git push -u origin main
```

Masukkan username dan password GitHub jika diminta.
> Jika minta token, buat di: GitHub → Settings → Developer settings → Personal access tokens → Generate new token (centang `repo`)

---

## 🚂 STEP 3 — Deploy di Railway

### 3.1 Login ke Railway
1. Buka [railway.app](https://railway.app)
2. Klik **"Login"** → pilih **"Login with GitHub"**
3. Izinkan Railway mengakses GitHub kamu

### 3.2 Buat Project Baru
1. Di dashboard Railway, klik **"New Project"**
2. Pilih **"Deploy from GitHub repo"**
3. Kalau belum authorize, klik **"Configure GitHub App"** dan izinkan akses ke repository `himedic-app`
4. Pilih repository **`himedic-app`**

### 3.3 Tunggu Deploy Otomatis
Railway akan otomatis:
- Mendeteksi Python + `requirements.txt`
- Install semua dependencies
- Menjalankan `gunicorn app:app` dari `Procfile`

Proses ini memakan waktu **5–15 menit** karena TensorFlow cukup besar (~500MB).

Pantau log di tab **"Deploy"** — kamu bisa lihat progress instalasi.

### 3.4 Dapatkan URL Publik
Setelah deploy berhasil (status: **Active**):
1. Klik tab **"Settings"** pada service
2. Scroll ke bagian **"Networking"**
3. Klik **"Generate Domain"**
4. Railway akan memberikan URL seperti: `https://himedic-app-production.up.railway.app`

🎉 **Aplikasimu sudah live!**

---

## ⚙️ STEP 4 — Konfigurasi Environment Variable (Opsional tapi Disarankan)

Di Railway → tab **"Variables"**, tambahkan:

| Key | Value |
|---|---|
| `PYTHONUNBUFFERED` | `1` |
| `PORT` | `8080` |

Ini memastikan log Railway tampil real-time dan port berjalan dengan benar.

---

## 🐛 Troubleshooting Deploy Gagal

### ❌ Error: `ModuleNotFoundError: No module named 'h5py'`
Pastikan `h5py==3.7.0` sudah ada di `requirements.txt`, lalu push ulang:
```bash
git add requirements.txt
git commit -m "fix: tambah h5py"
git push
```

### ❌ Error: `[nltk_data] Error loading punkt`
Pastikan kode download NLTK sudah ditambahkan di `app.py` seperti di STEP 1.

### ❌ Error: `Memory limit exceeded` / App crash saat startup
TensorFlow membutuhkan RAM besar. Di Railway free tier, coba tambahkan variable:
```
TF_CPP_MIN_LOG_LEVEL = 3
```
Dan pastikan Procfile menggunakan `--workers 1` (jangan lebih).

### ❌ Error: `Port already in use` atau `bind: address already in use`
Tambahkan environment variable `PORT=8080` dan pastikan Railway menggunakan port tersebut.

### ❌ Deploy timeout (lebih dari 30 menit)
Railway memberi waktu build 30 menit. Kalau TensorFlow terlalu besar, coba gunakan `tensorflow-cpu` bukan `tensorflow` (sudah benar di requirements kamu).

---

## 🔄 Cara Update Aplikasi Setelah Deploy

Setiap kali kamu ubah kode, cukup push ke GitHub:
```bash
git add .
git commit -m "update: deskripsi perubahan"
git push
```
Railway akan otomatis re-deploy dalam 1–2 menit.

---

## 💰 Informasi Free Tier Railway

| Item | Keterangan |
|---|---|
| Credit gratis | $5/bulan |
| Estimasi pemakaian | Cukup untuk ~500 jam runtime/bulan |
| Perlu kartu kredit? | Tidak (untuk tier Hobby gratis) |
| Custom domain | Bisa, gratis |
| Sleep saat tidak aktif | Tidak (berbeda dengan Render free tier) |

---

## 📌 Alternatif Platform Gratis Lainnya

Jika Railway tidak cocok, berikut alternatif lain:

| Platform | Catatan |
|---|---|
| **Render** | Gratis tapi service tidur setelah 15 menit tidak aktif |
| **Fly.io** | $5 credit gratis, perlu install CLI |
| **Koyeb** | Gratis untuk 1 service kecil |

Railway tetap yang paling direkomendasikan untuk Flask + TensorFlow karena RAM-nya lebih besar di free tier.

---

## ✅ Checklist Sebelum Deploy

- [ ] `Procfile` berisi `web: gunicorn app:app --workers 1 --timeout 120`
- [ ] `runtime.txt` berisi `python-3.10.13`
- [ ] `requirements.txt` sudah ditambah `h5py==3.7.0` dan `gunicorn==20.1.0`
- [ ] Kode download NLTK sudah ditambahkan di `app.py`
- [ ] File `.gitignore` sudah dibuat
- [ ] Semua file sudah di-push ke GitHub
- [ ] Repository sudah terhubung ke Railway
- [ ] Environment variables sudah diset di Railway

---

*Panduan ini dibuat untuk HiMedic — Python Health AI Diagnosis Chatbot*
